package com.panduprabs.githubusersapi.models

data class UsersResponses(
    val items: List<User>
)