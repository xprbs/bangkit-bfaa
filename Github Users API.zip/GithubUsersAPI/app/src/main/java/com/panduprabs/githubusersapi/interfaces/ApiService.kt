package com.panduprabs.githubusersapi.interfaces

import com.panduprabs.githubusersapi.models.DetailUserResponses
import com.panduprabs.githubusersapi.models.User
import com.panduprabs.githubusersapi.models.UsersResponses
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @GET("users/{username}")
    @Headers("Authorization: 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")
    fun getDetailUsers(@Path("username") username: String): Call<DetailUserResponses>

    @GET("users/{username}/followers")
    @Headers("Authorization: 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")
    fun getUserFollowers(
        @Path("username") username: String): Call<List<User>>

    @GET("users/{username}/following")
    @Headers("Authorization: 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")
    fun getUserFollowing(@Path("username") username: String): Call<List<User>>

    @GET("search/users")
    @Headers("Authorization: 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")
    fun searchUsers(@Query("q") username: String): Call<UsersResponses>
}