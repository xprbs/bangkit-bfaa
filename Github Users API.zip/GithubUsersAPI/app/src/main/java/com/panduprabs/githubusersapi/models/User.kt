package com.panduprabs.githubusersapi.models

data class User(
    val id: Int,
    val login: String,
    val avatar_url: String,
    val company: String,
    val location: String,
    val name: String,
)
